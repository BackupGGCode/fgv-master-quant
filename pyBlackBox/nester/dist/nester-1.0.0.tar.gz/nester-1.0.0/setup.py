from distutils.core import setup

setup(
    name            =   'nester',
    version         =   '1.0.0',
    py_modules      =   ['nester'],
    author          =   'hfpython',
    author_email    =   'saito.milton@gmail.com',
    url             =   'www.com',
    description     =   'a simple printer of nested lists',
)

